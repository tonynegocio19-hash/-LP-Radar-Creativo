/**
 * CONFIGURACIÓN DE ENLACES DE COBRO HOTMART
 * 
 * Puedes pegar aquí tus enlaces directos de checkout de Hotmart:
 * Ejemplos de formato Hotmart:
 * - https://pay.hotmart.com/TU_CODIGO_DE_PRODUCTO?checkoutMode=10
 * - https://go.hotmart.com/TU_HOTLINK
 * 
 * También puedes configurarlo directamente desde el botón "⚙️ Configurar Hotmart"
 * en la esquina inferior de la página para probarlo de inmediato en vivo.
 */

export const HOTMART_CONFIG = {
  // Enlace principal o universal de Hotmart
  defaultCheckoutUrl: 'https://pay.hotmart.com/',

  // (Opcional) Enlaces específicos por moneda si creaste dos ofertas distintas en Hotmart:
  checkoutUrlMXN: '', // Ej: https://pay.hotmart.com/TU_PRODUCTO_MXN
  checkoutUrlUSD: '', // Ej: https://pay.hotmart.com/TU_PRODUCTO_USD
};

const STORAGE_KEY_HOTMART = 'rc_hotmart_checkout_url';
const STORAGE_KEY_HOTMART_MXN = 'rc_hotmart_checkout_url_mxn';
const STORAGE_KEY_HOTMART_USD = 'rc_hotmart_checkout_url_usd';

export function getHotmartUrl(currency?: 'MXN' | 'USD'): string {
  if (typeof window === 'undefined') return HOTMART_CONFIG.defaultCheckoutUrl;

  // Check currency-specific override in localStorage
  if (currency === 'MXN') {
    const savedMxn = localStorage.getItem(STORAGE_KEY_HOTMART_MXN);
    if (savedMxn && savedMxn.trim()) return savedMxn.trim();
    if (HOTMART_CONFIG.checkoutUrlMXN && HOTMART_CONFIG.checkoutUrlMXN.trim()) {
      return HOTMART_CONFIG.checkoutUrlMXN.trim();
    }
  }

  if (currency === 'USD') {
    const savedUsd = localStorage.getItem(STORAGE_KEY_HOTMART_USD);
    if (savedUsd && savedUsd.trim()) return savedUsd.trim();
    if (HOTMART_CONFIG.checkoutUrlUSD && HOTMART_CONFIG.checkoutUrlUSD.trim()) {
      return HOTMART_CONFIG.checkoutUrlUSD.trim();
    }
  }

  // Check general override in localStorage
  const savedGeneral = localStorage.getItem(STORAGE_KEY_HOTMART);
  if (savedGeneral && savedGeneral.trim()) {
    return savedGeneral.trim();
  }

  return HOTMART_CONFIG.defaultCheckoutUrl;
}

export function saveHotmartUrl(url: string, currency?: 'MXN' | 'USD') {
  if (typeof window === 'undefined') return;

  if (currency === 'MXN') {
    localStorage.setItem(STORAGE_KEY_HOTMART_MXN, url.trim());
  } else if (currency === 'USD') {
    localStorage.setItem(STORAGE_KEY_HOTMART_USD, url.trim());
  } else {
    localStorage.setItem(STORAGE_KEY_HOTMART, url.trim());
  }
}
