/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Currency } from './types';
import { TopBar } from './components/TopBar';
import { HeroSection } from './components/HeroSection';
import { AudienceCheckSection } from './components/AudienceCheckSection';
import { PainPointsSection } from './components/PainPointsSection';
import { MethodSection } from './components/MethodSection';
import { CostOfWaitingSection } from './components/CostOfWaitingSection';
import { BonusesSection } from './components/BonusesSection';
import { TestimonialsSection } from './components/TestimonialsSection';
import { PricingTableSection } from './components/PricingTableSection';
import { GuaranteeSection } from './components/GuaranteeSection';
import { FaqSection } from './components/FaqSection';
import { FinalCtaSection } from './components/FinalCtaSection';
import { Footer } from './components/Footer';
import { CheckoutModal } from './components/CheckoutModal';
import { BonusDemoModal } from './components/BonusDemoModal';
import { StickyMobileBar } from './components/StickyMobileBar';
import { HotmartConfigModal } from './components/HotmartConfigModal';
import { SocialProofToast } from './components/SocialProofToast';
import { getHotmartUrl } from './config/checkout';
import { Link2, Settings } from 'lucide-react';

export default function App() {
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isHotmartConfigOpen, setIsHotmartConfigOpen] = useState(false);
  const [selectedBonusDemo, setSelectedBonusDemo] = useState<string | null>(null);
  const [currency, setCurrency] = useState<Currency>('MXN');

  // Unified Checkout Handler: checks if Hotmart link is configured, else opens checkout modal
  const handleOpenCheckout = () => {
    const hotmartUrl = getHotmartUrl(currency);
    const hasCustomLink = 
      hotmartUrl && 
      hotmartUrl !== 'https://pay.hotmart.com/' && 
      hotmartUrl.trim().length > 18;

    if (hasCustomLink) {
      const openInNewTab = localStorage.getItem('rc_hotmart_open_new_tab') !== 'false';
      if (openInNewTab) {
        window.open(hotmartUrl, '_blank', 'noopener,noreferrer');
      } else {
        window.location.href = hotmartUrl;
      }
    } else {
      // If creator has not set the Hotmart link yet, show checkout modal with Hotmart paste prompt
      setIsCheckoutOpen(true);
    }
  };

  const handleCloseCheckout = () => {
    setIsCheckoutOpen(false);
  };

  const handleOpenBonusDemo = (bonusId: string) => {
    setSelectedBonusDemo(bonusId);
  };

  const handleCloseBonusDemo = () => {
    setSelectedBonusDemo(null);
  };

  const handleToggleCurrency = (newCurrency: Currency) => {
    setCurrency(newCurrency);
  };

  const currentHotmartLink = getHotmartUrl(currency);
  const isHotmartActive = currentHotmartLink && currentHotmartLink !== 'https://pay.hotmart.com/' && currentHotmartLink.trim().length > 18;

  return (
    <div className="min-h-screen bg-[#0b0c0e] text-neutral-100 flex flex-col font-['Montserrat'] selection:bg-amber-400 selection:text-black">
      {/* 3-Zone Clean Header */}
      <TopBar onOpenCheckout={handleOpenCheckout} />

      {/* Main Content Flow with Strict Section Contrast */}
      <main className="flex-1 flex flex-col w-full">
        {/* Section 1: Dark #0d0e12 - Hero & Key Bullets */}
        <HeroSection onOpenCheckout={handleOpenCheckout} />

        {/* Section 2: Light #fbfbfa - ¿Esto es para mí? & Interactive Self-Test */}
        <AudienceCheckSection />

        {/* Section 3: Warm Stone #ebe8e1 - Sensación de tener algo dentro & Neblina Creativa */}
        <PainPointsSection />

        {/* Section 4: Dark Navy Slate #0c1017 - Mapa de Práctica Dirigida & Método en 3 Pasos */}
        <MethodSection onOpenCheckout={handleOpenCheckout} />

        {/* Section 5: Bespoke Swiss Ledger - Seguir esperando también tiene un costo */}
        <CostOfWaitingSection onOpenCheckout={handleOpenCheckout} />

        {/* Section 6: Dark Charcoal #101216 - 4 Bonos Interactivos */}
        <BonusesSection 
          onOpenBonusDemo={handleOpenBonusDemo} 
          onOpenCheckout={handleOpenCheckout} 
        />

        {/* Section 7: Pure White #ffffff - Lo que están diciendo (Testimonios reales) */}
        <TestimonialsSection />

        {/* Section 8: Dark Obsidian #0a0b0e - Resumen de tu acceso & Tabla de valor */}
        <PricingTableSection 
          onOpenCheckout={handleOpenCheckout}
          currency={currency}
          onToggleCurrency={handleToggleCurrency}
        />

        {/* Section 9: Light Ivory #fbf9f4 - Garantía incondicional de 7 días */}
        <GuaranteeSection onOpenCheckout={handleOpenCheckout} />

        {/* Section 10: Dark Obsidian #0c0d11 - Preguntas Frecuentes (9 FAQs) */}
        <FaqSection />

        {/* Section 11: Dark Graphite #12141a - Cierre, Llamado Final & Nombres considerados */}
        <FinalCtaSection onOpenCheckout={handleOpenCheckout} />
      </main>

      {/* Quiet Minimalist Footer with Hotmart Config link */}
      <Footer onOpenHotmartConfig={() => setIsHotmartConfigOpen(true)} />

      {/* Conversion Floating Bar for Mobile/Desktop */}
      <StickyMobileBar 
        onOpenCheckout={handleOpenCheckout} 
        currency={currency} 
      />

      {/* Dynamic Social Proof Sales Notifications in bottom-left, triggered on offer scroll */}
      <SocialProofToast 
        targetSectionId="oferta" 
        onOpenCheckout={handleOpenCheckout} 
      />

      {/* Quick Hotmart Setup Floating Button for Administrator (positioned at bottom-right) */}
      <div className="fixed bottom-14 sm:bottom-4 right-4 z-30">
        <button
          onClick={() => setIsHotmartConfigOpen(true)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-bold shadow-lg transition-all border ${
            isHotmartActive 
              ? 'bg-neutral-900/90 hover:bg-neutral-800 text-emerald-400 border-emerald-500/40 backdrop-blur-md'
              : 'bg-amber-400 hover:bg-amber-300 text-black border-amber-500 animate-pulse'
          }`}
          title="Haz clic para colocar o editar tu enlace de Hotmart"
        >
          {isHotmartActive ? (
            <>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>Hotmart Conectado</span>
            </>
          ) : (
            <>
              <Link2 className="w-3.5 h-3.5" />
              <span>Colocar Link de Hotmart</span>
            </>
          )}
        </button>
      </div>

      {/* Conversion Checkout Flow Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={handleCloseCheckout}
        currency={currency}
        onToggleCurrency={handleToggleCurrency}
        onOpenHotmartConfig={() => {
          setIsCheckoutOpen(false);
          setIsHotmartConfigOpen(true);
        }}
      />

      {/* Dedicated Hotmart Configuration Modal */}
      <HotmartConfigModal
        isOpen={isHotmartConfigOpen}
        onClose={() => setIsHotmartConfigOpen(false)}
      />

      {/* Interactive Bonus Demo Tester Modal */}
      <BonusDemoModal
        bonusId={selectedBonusDemo}
        onClose={handleCloseBonusDemo}
        onOpenCheckout={handleOpenCheckout}
      />
    </div>
  );
}
