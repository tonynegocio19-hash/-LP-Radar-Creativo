export type Currency = 'USD' | 'MXN';

export interface PricingInfo {
  currency: Currency;
  regularPrice: string;
  promoPrice: string;
  symbol: string;
  savingsNote: string;
}

export interface BonusItem {
  id: string;
  badge: string;
  title: string;
  subtitle: string;
  description: string;
  value: string;
  interactiveLabel: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface TestimonialItem {
  quote: string;
  name: string;
  role: string;
  discipline: string;
  location: string;
}
