import React from 'react';
import { AlertTriangle, Compass, RefreshCw } from 'lucide-react';

export const PainPointsSection: React.FC = () => {
  return (
    <section className="w-full bg-[#ebe8e1] text-[#1c1d22] py-20 sm:py-28 border-b border-[#d8d3c8]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Main Section Heading */}
        <div className="max-w-3xl mb-12 sm:mb-16">
          <span className="text-xs font-bold tracking-[0.2em] uppercase text-neutral-600 block mb-3">
            El Origen del Estancamiento
          </span>
          <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black text-[#14151a] tracking-tight leading-[1.15]">
            ESA SENSACIÓN DE TENER ALGO DENTRO Y NO PODER SACARLO
          </h2>
        </div>

        {/* Bento-style clean layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Card 1: The symptoms */}
          <div className="lg:col-span-6 p-8 sm:p-10 rounded-2xl bg-[#f4f2ec] border border-[#d8d3c8] flex flex-col justify-between space-y-6 shadow-sm">
            <div className="space-y-4">
              <div className="w-10 h-10 rounded-xl bg-neutral-900 text-white flex items-center justify-center">
                <AlertTriangle className="w-5 h-5 text-amber-300" />
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-neutral-900 leading-snug">
                El ciclo silencioso de las ideas acumuladas
              </h3>
              <p className="text-base sm:text-lg text-neutral-700 leading-relaxed font-normal">
                Tienes proyectos pendientes, notas llenas de ideas y archivos con nombres como “versión final 3”. Cada vez que intentas avanzar, aparece cansancio, duda o una exigencia imposible.
              </p>
            </div>

            <div className="pt-4 border-t border-[#d8d3c8]/80 text-xs text-neutral-500 font-semibold uppercase tracking-wider">
              Diagnóstico: Fricción por sobre-exigencia
            </div>
          </div>

          {/* Card 2: Neblina Creativa (Marquee spotlight with editorial photo) */}
          <div className="lg:col-span-6 relative rounded-2xl overflow-hidden border border-[#d8d3c8] bg-neutral-900 text-white shadow-md flex flex-col justify-end p-8 sm:p-10 group min-h-[380px]">
            <img
              src="/src/assets/images/creative_breakthrough_concept_1793863718487.jpg"
              alt="Metáfora visual de la neblina creativa y la claridad mental"
              referrerPolicy="no-referrer"
              className="absolute inset-0 w-full h-full object-cover object-center transition-transform duration-700 group-hover:scale-103"
            />
            {/* Scrim */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/60 to-black/20" />

            <div className="relative z-10 space-y-4">
              <span className="text-[11px] font-bold uppercase tracking-widest text-amber-400">
                El Diagnóstico Exacto
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-white leading-snug">
                El problema tiene un nombre: Neblina Creativa.
              </h3>
              <p className="text-sm sm:text-base text-neutral-200 leading-relaxed font-normal">
                Tu mente mezcla demasiadas opciones, miedo a equivocarte y objetivos poco concretos hasta convertir el primer paso en una pared.
              </p>
            </div>
          </div>

          {/* Card 3: Why previous methods failed */}
          <div className="lg:col-span-12 p-8 sm:p-10 rounded-2xl bg-[#ded9cf] border border-[#ccc6b9] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
            <div className="space-y-2 max-w-3xl">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-neutral-600">
                <RefreshCw className="w-4 h-4 text-neutral-800" />
                <span>La trampa de la solución equivocada</span>
              </div>
              <p className="text-base sm:text-lg text-neutral-900 font-medium leading-relaxed">
                Ya intentaste esperar inspiración, consumir más contenido y comenzar otro proyecto. Falló porque estabas usando la misma estrategia para bloqueos distintos.
              </p>
            </div>

            <div className="shrink-0 px-4 py-2.5 rounded-lg bg-neutral-900 text-white text-xs font-bold uppercase tracking-wider whitespace-nowrap">
              Necesitas un Sistema, No Inspiración
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
