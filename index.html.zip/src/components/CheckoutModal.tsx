import React, { useState } from 'react';
import { X, ShieldCheck, Check, Lock, Zap, ArrowRight, CreditCard, Sparkles } from 'lucide-react';
import { Currency } from '../types';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  onToggleCurrency: (c: Currency) => void;
  onOpenHotmartConfig?: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  currency,
  onToggleCurrency,
  onOpenHotmartConfig,
}) => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'paypal' | 'apple'>('card');

  if (!isOpen) return null;

  const priceFormatted = currency === 'MXN' ? '$250.00 MXN' : '$27.00 USD';
  const originalFormatted = currency === 'MXN' ? '$3,000.00 MXN' : '$430.00 USD';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
    }, 900);
  };

  const handleReset = () => {
    setIsSuccess(false);
    setEmail('');
    setName('');
    setCardNumber('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-xl bg-[#0f1116] border border-white/15 rounded-2xl shadow-2xl p-6 sm:p-8 text-neutral-100 overflow-hidden max-h-[92vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={handleReset}
          className="absolute top-5 right-5 p-2 text-neutral-400 hover:text-white rounded-lg transition-colors hover:bg-white/10"
          aria-label="Cerrar ventana de compra"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSuccess ? (
          <>
            {/* Header */}
            <div className="border-b border-white/10 pb-5">
              <span className="text-[11px] font-bold uppercase tracking-widest text-amber-400">
                Paso Final · Acceso Inmediato
              </span>
              <h2 className="text-2xl font-black text-white tracking-tight mt-1">
                Comienza tu Diagnóstico en Radar Creativo
              </h2>
              <p className="text-xs text-neutral-400 mt-1">
                Recibirás las credenciales y el enlace interactivo directamente en tu correo.
              </p>
            </div>

            {/* Hotmart Direct Link Banner / Shortcut */}
            {onOpenHotmartConfig && (
              <div className="mt-3 p-3 rounded-xl bg-amber-400/10 border border-amber-400/25 flex items-center justify-between gap-3">
                <div className="text-[11px] text-amber-200">
                  <span className="font-bold text-amber-300">¿Vas a cobrar con Hotmart?</span> Coloca tu enlace de checkout para recibir los pagos directo en tu cuenta.
                </div>
                <button
                  type="button"
                  onClick={onOpenHotmartConfig}
                  className="px-2.5 py-1.5 rounded-lg bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-[11px] uppercase tracking-wider transition-colors shrink-0 whitespace-nowrap"
                >
                  Pegar Link Hotmart
                </button>
              </div>
            )}

            {/* Currency selector tabs */}
            <div className="flex items-center justify-between pt-3 pb-2">
              <span className="text-xs text-neutral-300 font-medium">Moneda preferida:</span>
              <div className="flex items-center gap-1 p-1 bg-white/5 border border-white/10 rounded-lg text-xs font-semibold">
                <button
                  type="button"
                  onClick={() => onToggleCurrency('MXN')}
                  className={`px-2.5 py-1 rounded transition-colors ${currency === 'MXN' ? 'bg-amber-400 text-black font-bold' : 'text-neutral-400 hover:text-white'}`}
                >
                  $250 MXN
                </button>
                <button
                  type="button"
                  onClick={() => onToggleCurrency('USD')}
                  className={`px-2.5 py-1 rounded transition-colors ${currency === 'USD' ? 'bg-amber-400 text-black font-bold' : 'text-neutral-400 hover:text-white'}`}
                >
                  $27 USD
                </button>
              </div>
            </div>

            {/* Scrollable form */}
            <form onSubmit={handleSubmit} className="overflow-y-auto space-y-4 py-2 flex-1 pr-1 text-xs sm:text-sm">
              {/* Order recap box */}
              <div className="p-3.5 rounded-xl bg-white/[0.03] border border-white/10 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-white">Radar Creativo + 4 Bonos Interactivos</span>
                  <div className="text-right">
                    <span className="text-xs text-neutral-400 line-through mr-1.5">{originalFormatted}</span>
                    <span className="font-bold text-amber-400 text-base">{priceFormatted}</span>
                  </div>
                </div>
                <div className="flex flex-wrap gap-x-3 gap-y-1 text-[11px] text-neutral-400 border-t border-white/5 pt-2">
                  <span className="flex items-center gap-1">
                    <Check className="w-3 h-3 text-emerald-400" /> Test de Fricción
                  </span>
                  <span className="flex items-center gap-1">
                    <Check className="w-3 h-3 text-emerald-400" /> Generador 20 Min
                  </span>
                  <span className="flex items-center gap-1">
                    <Check className="w-3 h-3 text-emerald-400" /> Checklist Sesión
                  </span>
                  <span className="flex items-center gap-1">
                    <Check className="w-3 h-3 text-emerald-400" /> Simulador Días Malos
                  </span>
                </div>
              </div>

              {/* Personal Data */}
              <div className="space-y-3">
                <div>
                  <label className="block text-[11px] font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                    Nombre completo
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ej. Sofía Morales"
                    value={name}
                    onChange={e => setName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/15 text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-semibold text-neutral-300 uppercase tracking-wider mb-1">
                    Correo electrónico para entrega de acceso
                  </label>
                  <input
                    type="email"
                    required
                    placeholder="tu-correo@ejemplo.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/15 text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Payment selector */}
              <div>
                <label className="block text-[11px] font-semibold text-neutral-300 uppercase tracking-wider mb-1.5">
                  Método de pago seguro
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`py-2 px-2 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'card'
                        ? 'border-amber-400 bg-amber-400/15 text-amber-300'
                        : 'border-white/10 bg-white/5 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Tarjeta</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('apple')}
                    className={`py-2 px-2 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'apple'
                        ? 'border-amber-400 bg-amber-400/15 text-amber-300'
                        : 'border-white/10 bg-white/5 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <span>Apple / GPay</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('paypal')}
                    className={`py-2 px-2 rounded-lg border text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                      paymentMethod === 'paypal'
                        ? 'border-amber-400 bg-amber-400/15 text-amber-300'
                        : 'border-white/10 bg-white/5 text-neutral-400 hover:text-white'
                    }`}
                  >
                    <span>PayPal</span>
                  </button>
                </div>
              </div>

              {paymentMethod === 'card' && (
                <div className="space-y-2.5 pt-1">
                  <div>
                    <input
                      type="text"
                      placeholder="Número de tarjeta (simulación 4242...)"
                      value={cardNumber}
                      onChange={e => setCardNumber(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/15 text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 text-xs"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="MM/AA"
                      className="px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/15 text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 text-xs"
                    />
                    <input
                      type="text"
                      placeholder="CVC"
                      className="px-3.5 py-2.5 rounded-xl bg-black/40 border border-white/15 text-white placeholder-neutral-500 focus:outline-none focus:border-amber-400 text-xs"
                    />
                  </div>
                </div>
              )}

              {/* Guarantee statement */}
              <div className="flex items-start gap-2.5 p-3 rounded-xl bg-emerald-500/10 border border-emerald-400/25 text-emerald-200 text-xs">
                <ShieldCheck className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
                <p>
                  <strong className="text-white">Garantía incondicional de 7 días:</strong> Si tras completar el diagnóstico sientes que no te dio claridad, te devolvemos el 100% de tu dinero de inmediato.
                </p>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-3.5 px-4 bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-xs sm:text-sm uppercase tracking-wider rounded-xl transition-all shadow-lg hover:shadow-amber-400/20 flex items-center justify-center gap-2 mt-2"
              >
                {isSubmitting ? (
                  <span>Procesando pago seguro...</span>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Pagar {priceFormatted} y Acceder Ahora</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-4 text-[10px] text-neutral-400 text-center pt-1">
                <span>Encriptación SSL 256-Bit</span>
                <span>·</span>
                <span>Acceso Inmediato</span>
                <span>·</span>
                <span>Sin suscripciones recurrentes</span>
              </div>
            </form>
          </>
        ) : (
          /* Confirmation State */
          <div className="py-6 space-y-6 text-center animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 bg-emerald-500/20 border border-emerald-400/40 rounded-full flex items-center justify-center mx-auto text-emerald-400">
              <Check className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <span className="text-[11px] font-bold uppercase tracking-widest text-emerald-400">
                ¡Orden Completada con Éxito!
              </span>
              <h2 className="text-2xl font-black text-white">
                Bienvenido a Radar Creativo
              </h2>
              <p className="text-xs sm:text-sm text-neutral-300 max-w-md mx-auto leading-relaxed">
                Hemos enviado las credenciales y el enlace interactivo a <strong className="text-white">{email || 'tu correo'}</strong>. Ya puedes iniciar tu sesión diagnóstica de 12 minutos.
              </p>
            </div>

            <div className="p-4 rounded-xl bg-white/[0.04] border border-white/10 text-left text-xs space-y-2 max-w-md mx-auto">
              <div className="flex justify-between text-neutral-400">
                <span>ID de Acceso:</span>
                <span className="font-mono text-white">RC-2026-LIVE</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Herramientas activas:</span>
                <span className="text-emerald-400 font-semibold">Diagnóstico + 4 Bonos</span>
              </div>
              <div className="flex justify-between text-neutral-400">
                <span>Garantía:</span>
                <span className="text-white">7 días incondicional</span>
              </div>
            </div>

            <button
              onClick={handleReset}
              className="w-full max-w-md mx-auto py-3.5 px-6 bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-xs sm:text-sm uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4" />
              <span>Abrir Mi Diagnóstico Interactivo Ahora</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
