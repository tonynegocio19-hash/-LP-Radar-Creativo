import React from 'react';
import { ArrowRight, Compass, Sparkles, CheckCircle2 } from 'lucide-react';

interface FinalCtaSectionProps {
  onOpenCheckout: () => void;
}

export const FinalCtaSection: React.FC<FinalCtaSectionProps> = ({ onOpenCheckout }) => {
  const consideredNames = [
    'Mapa Creativo',
    'Perfil Creativo',
    'Diagnóstico Creativo',
    'Ruta Creativa',
  ];

  return (
    <section className="w-full bg-[#12141a] text-neutral-100 py-20 sm:py-32 relative overflow-hidden">
      {/* Background radial glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[360px] bg-amber-500/10 blur-[140px] pointer-events-none rounded-full" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 relative z-10 space-y-16">
        
        {/* Dual Secondary CTAs from copy */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onOpenCheckout}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl border border-white/20 hover:border-amber-400 bg-white/5 hover:bg-white/10 text-white font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
          >
            <span>IDENTIFICAR LO QUE ME ESTÁ FRENANDO</span>
            <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
          </button>

          <button
            onClick={onOpenCheckout}
            className="w-full sm:w-auto px-6 py-3.5 rounded-xl border border-white/20 hover:border-amber-400 bg-white/5 hover:bg-white/10 text-white font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2"
          >
            <span>RECUPERAR MI PRIMERA SESIÓN</span>
            <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
          </button>
        </div>

        {/* The Emotional & Practical Climax Block */}
        <div className="text-center max-w-3xl mx-auto space-y-8 pt-4">
          <h2 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.1] text-balance">
            Deja de cargar con ideas que nunca llegan a existir
          </h2>

          <div className="space-y-4 text-base sm:text-xl font-medium text-neutral-300 max-w-2xl mx-auto leading-relaxed">
            <p>
              Merecías una forma concreta de entender por qué te detienes.
            </p>
            <p>
              Merecías crear sin esperar a sentirte completamente preparado.
            </p>
            <p className="font-bold text-white text-lg sm:text-2xl pt-2">
              Hoy puedes dejar de acumular proyectos pendientes y empezar con una acción que sí puedas completar.
            </p>
          </div>

          {/* Master Conversion CTA */}
          <div className="pt-4">
            <button
              onClick={onOpenCheckout}
              className="w-full sm:w-auto px-10 py-5 bg-amber-400 hover:bg-amber-300 text-black font-black text-sm sm:text-base uppercase tracking-wider rounded-2xl transition-all shadow-2xl hover:shadow-amber-400/30 inline-flex items-center justify-center gap-3 group"
            >
              <span>VOLVER A CREAR SIN SEGUIR POSTERGANDO</span>
              <ArrowRight className="w-5 h-5 transition-transform group-hover:translate-x-1" />
            </button>
          </div>

          <div className="text-xs text-neutral-400 font-semibold tracking-wide flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Acceso digital vitalicio · Diagnóstico interactivo de 12 minutos · 4 bonos incluidos
          </div>
        </div>

        {/* Considered Names Note (From prompt brief) */}
        <div className="pt-12 border-t border-white/10 max-w-2xl mx-auto text-center space-y-3">
          <span className="text-[11px] font-bold uppercase tracking-widest text-neutral-500">
            Evolución Conceptual del Framework
          </span>
          <p className="text-xs text-neutral-400 leading-relaxed font-normal">
            Durante el diseño del sistema se evaluaron conceptos como{' '}
            <strong className="text-neutral-300">{consideredNames.join(', ')}</strong>, antes de consolidar el diagnóstico integral en la arquitectura de <strong className="text-amber-400">Radar Creativo</strong>.
          </p>
        </div>

      </div>
    </section>
  );
};
