import React, { useState } from 'react';
import { CheckSquare, Square, ArrowDown, AlertCircle } from 'lucide-react';

export const AudienceCheckSection: React.FC = () => {
  const [checkedItems, setCheckedItems] = useState<Record<number, boolean>>({
    0: true,
    1: true,
    2: true,
    3: false,
  });

  const criteria = [
    'Tienes ideas guardadas, pero pocas llegan a convertirse en algo terminado.',
    'Abres un cuaderno o una pantalla y no sabes por dónde comenzar.',
    'Cambias de proyecto cada vez que aparece una parte difícil.',
    'Te comparas con personas que producen más y terminas dudando de tu capacidad.',
  ];

  const toggleCheck = (idx: number) => {
    setCheckedItems(prev => ({ ...prev, [idx]: !prev[idx] }));
  };

  const yesCount = Object.values(checkedItems).filter(Boolean).length;

  return (
    <section id="para-quien" className="w-full bg-[#fbfbfa] text-[#121316] py-16 sm:py-24 border-b border-neutral-200">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-10 sm:mb-14">
          <span className="text-xs font-bold tracking-[0.2em] uppercase text-neutral-500 block mb-2">
            Autoevaluación Rápida
          </span>
          <h2 className="text-2xl sm:text-4xl font-black text-[#111216] tracking-tight">
            ¿ESTO ES PARA MÍ?
          </h2>
          <p className="mt-3 text-sm sm:text-base text-neutral-600 font-medium">
            Toca las casillas que coincidan con tu situación actual para medir tu nivel de fricción:
          </p>
        </div>

        {/* Interactive 4-Item List */}
        <div className="space-y-3.5 max-w-3xl mx-auto">
          {criteria.map((item, idx) => {
            const isChecked = !!checkedItems[idx];
            return (
              <div
                key={idx}
                onClick={() => toggleCheck(idx)}
                className={`flex items-start gap-4 p-5 sm:p-6 rounded-2xl border transition-all cursor-pointer select-none ${
                  isChecked
                    ? 'bg-white border-neutral-900 shadow-sm'
                    : 'bg-neutral-100/60 border-neutral-200 hover:border-neutral-400'
                }`}
                role="checkbox"
                aria-checked={isChecked}
                tabIndex={0}
                onKeyDown={e => {
                  if (e.key === ' ' || e.key === 'Enter') {
                    e.preventDefault();
                    toggleCheck(idx);
                  }
                }}
              >
                <div className="mt-0.5 text-neutral-900 shrink-0">
                  {isChecked ? (
                    <div className="w-6 h-6 rounded-md bg-neutral-900 text-white flex items-center justify-center">
                      <CheckSquare className="w-4 h-4 text-amber-300" />
                    </div>
                  ) : (
                    <div className="w-6 h-6 rounded-md border-2 border-neutral-300 flex items-center justify-center bg-white" />
                  )}
                </div>

                <p className={`text-base sm:text-lg font-medium leading-relaxed transition-colors ${
                  isChecked ? 'text-neutral-900 font-semibold' : 'text-neutral-600'
                }`}>
                  {item}
                </p>
              </div>
            );
          })}
        </div>

        {/* Counter and Verdict Callout */}
        <div className="mt-10 max-w-3xl mx-auto">
          <div className="p-6 rounded-2xl bg-neutral-100 border border-neutral-300 text-center space-y-3">
            <div className="text-xs font-bold uppercase tracking-wider text-neutral-500">
              Respuestas afirmativas: <span className="text-neutral-900 font-black">{yesCount} de 4</span>
            </div>

            <p className="text-base sm:text-xl font-bold text-neutral-900 leading-snug">
              Si respondiste que sí a 3 o más, sigue leyendo.
            </p>

            {yesCount >= 3 ? (
              <p className="text-xs sm:text-sm text-neutral-600 max-w-xl mx-auto font-normal">
                Tu patrón indica que el problema no es tu talento ni tus ideas, sino una sobrecarga de fricción en la transición de la mente a la acción. Descubre abajo qué está ocurriendo exactamente.
              </p>
            ) : (
              <p className="text-xs sm:text-sm text-neutral-500 max-w-xl mx-auto font-normal">
                Incluso con uno o dos bloqueos activos, una pequeña fricción no resuelta puede congelar meses de trabajo creativo.
              </p>
            )}

            <div className="pt-2 flex justify-center text-neutral-400">
              <ArrowDown className="w-5 h-5 animate-bounce" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
