import React from 'react';

interface TopBarProps {
  onOpenCheckout: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({ onOpenCheckout }) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-[#0d0e12]/95 backdrop-blur-md border-b border-white/10 transition-colors">
      <div className="max-w-6xl mx-auto pl-4 pr-6 sm:px-8 h-16 flex items-center justify-between gap-3 sm:gap-8">
        {/* Zone 1: Single text element wordmark */}
        <a 
          href="#inicio" 
          className="text-sm sm:text-lg font-black tracking-widest text-white uppercase whitespace-nowrap shrink-0 hover:text-amber-400 transition-colors"
        >
          RADAR CREATIVO
        </a>

        {/* Zone 2: 4-5 single-line clean text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-xs font-semibold uppercase tracking-wider text-neutral-300">
          <a href="#para-quien" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            ¿Es para mí?
          </a>
          <a href="#metodo" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            El Método
          </a>
          <a href="#bonos" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Bonos
          </a>
          <a href="#testimonios" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Opiniones
          </a>
          <a href="#garantia" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Garantía
          </a>
          <a href="#faq" className="hover:text-white transition-colors whitespace-nowrap shrink-0">
            Preguntas
          </a>
        </nav>

        {/* Zone 3: 1 primary action (moved inward/left to prevent edge clipping) */}
        <div className="flex items-center shrink-0 mr-1 sm:mr-3">
          <button
            onClick={onOpenCheckout}
            className="px-3 sm:px-4 py-2 text-[11px] sm:text-xs font-extrabold uppercase tracking-wider text-black bg-amber-400 hover:bg-amber-300 rounded-lg transition-all shadow-sm hover:shadow-amber-400/20 whitespace-nowrap shrink-0"
          >
            Quiero Volver a Crear
          </button>
        </div>
      </div>
    </header>
  );
};
