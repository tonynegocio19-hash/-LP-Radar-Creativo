import React from 'react';
import { Check, ArrowRight, ShieldCheck, Clock, Sparkles } from 'lucide-react';

interface HeroSectionProps {
  onOpenCheckout: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onOpenCheckout }) => {
  const bullets = [
    'El Perfil de Fricción que muestra qué está frenando tus ideas: perfeccionismo, saturación o falta de práctica.',
    'El diagnóstico de 12 minutos que reemplaza semanas de reflexión confusa.',
    'El punto ciego que te hace creer que te falta talento cuando en realidad te falta un sistema.',
    'El plan de 24 horas para volver a crear sin esperar a sentirte inspirado.',
    'La herramienta que separa una idea interesante de un proyecto que sí puedes terminar.',
  ];

  return (
    <section id="inicio" className="relative w-full bg-[#0d0e12] text-neutral-100 pt-12 pb-20 md:pt-20 md:pb-28 border-b border-white/10 overflow-hidden">
      {/* Subtle radial ambient light */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-amber-500/10 blur-[130px] pointer-events-none rounded-full" />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        {/* Brand Kicker */}
        <div className="mb-4">
          <span className="text-xs sm:text-sm font-black tracking-[0.25em] uppercase text-amber-400">
            RADAR CREATIVO
          </span>
        </div>

        {/* Main Headline */}
        <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.08] max-w-4xl text-balance text-center mx-auto">
          Deja de mirar tus ideas sin terminar
        </h1>

        {/* Subtitle */}
        <p className="mt-5 text-base sm:text-xl font-medium text-neutral-300 max-w-2xl leading-relaxed">
          Diagnóstico interactivo que detecta tu bloqueo creativo y genera una ruta de práctica ajustada a tu tiempo.
        </p>

        {/* 2-Column Split: Key Bullets + CTA Box on left, Architectural Visual on right */}
        <div className="mt-10 lg:mt-14 grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-stretch">
          
          {/* Left Column (7 cols): Bullets and Pricing Box */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-8">
            {/* The 5 bullets */}
            <ul className="space-y-4 text-sm sm:text-base text-neutral-200">
              {bullets.map((bullet, idx) => (
                <li key={idx} className="flex items-start gap-3.5">
                  <div className="mt-0.5 w-5 h-5 rounded-md bg-amber-400/15 border border-amber-400/40 text-amber-400 flex items-center justify-center shrink-0">
                    <Check className="w-3.5 h-3.5 stroke-[2.5]" />
                  </div>
                  <span className="font-normal leading-relaxed text-neutral-200">
                    {bullet}
                  </span>
                </li>
              ))}
            </ul>

            {/* Pricing & CTA Card */}
            <div className="p-6 sm:p-7 rounded-2xl bg-white/[0.03] border border-white/15 space-y-4">
              <div className="flex flex-wrap items-baseline gap-3">
                <span className="text-xs sm:text-sm font-semibold uppercase tracking-wider text-neutral-400">
                  Oferta de lanzamiento:
                </span>
                <span className="text-sm sm:text-base font-semibold text-neutral-400 line-through">
                  De $3000.00
                </span>
                <span className="text-2xl sm:text-3xl font-black text-amber-400 tracking-tight">
                  por $250.00
                </span>
                <span className="text-xs font-semibold text-neutral-400">
                  (o $27 USD)
                </span>
              </div>

              <p className="text-xs sm:text-sm font-medium text-neutral-300">
                Menos que una cena para saber qué está deteniendo tus proyectos y qué hacer hoy.
              </p>

              {/* Primary Hero CTA Button */}
              <div className="pt-1">
                <button
                  onClick={onOpenCheckout}
                  className="w-full sm:w-auto px-8 py-4 bg-amber-400 hover:bg-amber-300 text-black font-black text-sm uppercase tracking-wider rounded-xl transition-all shadow-xl hover:shadow-amber-400/25 flex items-center justify-center gap-3 group"
                >
                  <span>QUIERO VOLVER A CREAR</span>
                  <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
                </button>
              </div>

              {/* Micro-trust indicators */}
              <div className="flex flex-wrap items-center gap-4 text-xs text-neutral-400 pt-2 border-t border-white/5">
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-neutral-300" /> Diagnóstico de 12 minutos
                </span>
                <span className="flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-neutral-300" /> Garantía incondicional de 7 días
                </span>
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-neutral-300" /> 4 Bonos incluidos hoy
                </span>
              </div>
            </div>
          </div>

          {/* Right Column (5 cols): Visual Asset Frame with Diagnostic Card */}
          <div className="lg:col-span-5 flex flex-col justify-center">
            <div className="relative rounded-2xl overflow-hidden border border-white/15 bg-neutral-900 shadow-2xl group">
              <img
                src="/src/assets/images/hero_creative_workspace_1793863718236.jpg"
                alt="Espacio de trabajo creativo minimalista con cuaderno de notas"
                referrerPolicy="no-referrer"
                className="w-full h-full min-h-[340px] sm:min-h-[420px] object-cover object-center transition-transform duration-700 group-hover:scale-102"
              />

              {/* Contrast scrim for readability */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent" />

              {/* Floating Live Diagnostic Result Preview Card */}
              <div className="absolute bottom-5 left-5 right-5 p-4 rounded-xl bg-[#0f1116]/90 backdrop-blur-md border border-white/15 text-xs text-neutral-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
                    Muestra de Diagnóstico
                  </span>
                  <span className="text-[10px] font-mono text-neutral-400">
                    12 min · Sesión 01
                  </span>
                </div>
                <div className="text-sm font-bold text-white">
                  Perfil: Fricción por Perfeccionismo & Dispersión
                </div>
                <p className="text-neutral-300 text-[11px] leading-relaxed">
                  Ruta asignada: Micro-sesión de 18 min para destrabar el esqueleto esencial antes de entrar en detalle.
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
