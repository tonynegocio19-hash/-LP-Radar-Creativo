import React, { useState, useEffect, useRef } from 'react';
import { ShoppingBag, CheckCircle, X } from 'lucide-react';

interface SaleItem {
  name: string;
  city: string;
  plan: string;
  timeAgo: string;
}

const SALES_POOL: SaleItem[] = [
  { name: 'María', city: 'Ciudad de México', plan: 'Radar Creativo + 4 Bonos', timeAgo: 'hace 2 min' },
  { name: 'Carlos', city: 'Monterrey', plan: 'Diagnóstico Completo + Bonos', timeAgo: 'hace 3 min' },
  { name: 'Valentina', city: 'Bogotá', plan: 'Radar Creativo + 4 Bonos', timeAgo: 'hace 1 min' },
  { name: 'Andrés', city: 'Santiago', plan: 'Acceso Completo', timeAgo: 'hace 4 min' },
  { name: 'Lucía', city: 'Guadalajara', plan: 'Radar Creativo + 4 Bonos', timeAgo: 'hace 2 min' },
  { name: 'Mateo', city: 'Buenos Aires', plan: 'Diagnóstico Completo + Bonos', timeAgo: 'hace 5 min' },
  { name: 'Sofía', city: 'Madrid', plan: 'Radar Creativo + 4 Bonos', timeAgo: 'hace 1 min' },
  { name: 'Diego', city: 'Lima', plan: 'Acceso Completo', timeAgo: 'hace 3 min' },
  { name: 'Camila', city: 'Medellín', plan: 'Radar Creativo + 4 Bonos', timeAgo: 'hace 2 min' },
  { name: 'Javier', city: 'Puebla', plan: 'Radar Creativo + 4 Bonos', timeAgo: 'hace 4 min' },
];

interface SocialProofToastProps {
  targetSectionId?: string;
  onOpenCheckout?: () => void;
}

export const SocialProofToast: React.FC<SocialProofToastProps> = ({
  targetSectionId = 'oferta',
  onOpenCheckout,
}) => {
  const [hasReachedOffer, setHasReachedOffer] = useState(false);
  const [currentSale, setCurrentSale] = useState<SaleItem | null>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  const saleIndexRef = useRef(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const hideTimerRef = useRef<NodeJS.Timeout | null>(null);

  // 1. Detect when the user scrolls to the offer section
  useEffect(() => {
    const handleCheckSection = () => {
      const el = document.getElementById(targetSectionId);
      if (!el) return;

      const rect = el.getBoundingClientRect();
      // If the top of the offer section is within the viewport or scrolled past
      if (rect.top <= window.innerHeight * 0.85) {
        setHasReachedOffer(true);
      }
    };

    window.addEventListener('scroll', handleCheckSection, { passive: true });
    // Run once initially in case user arrived directly via anchor
    handleCheckSection();

    return () => window.removeEventListener('scroll', handleCheckSection);
  }, [targetSectionId]);

  // 2. Start social proof loop once offer section is reached
  useEffect(() => {
    if (!hasReachedOffer || isDismissed) return;

    const showNotification = () => {
      // Pick next sale
      const nextSale = SALES_POOL[saleIndexRef.current % SALES_POOL.length];
      saleIndexRef.current += 1;
      setCurrentSale(nextSale);
      setIsVisible(true);

      // Rule: Remain visible for 4 seconds, then disappear
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
      hideTimerRef.current = setTimeout(() => {
        setIsVisible(false);
      }, 4000);

      // Rule: Appear every 15–20 seconds (randomized between 15000 and 20000ms)
      const nextInterval = Math.floor(Math.random() * (20000 - 15000 + 1)) + 15000;
      timerRef.current = setTimeout(showNotification, nextInterval);
    };

    // First appearance: 1.5 seconds after reaching the offer section
    const initialDelay = setTimeout(showNotification, 1500);

    return () => {
      clearTimeout(initialDelay);
      if (timerRef.current) clearTimeout(timerRef.current);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, [hasReachedOffer, isDismissed]);

  if (!hasReachedOffer || isDismissed || !currentSale) {
    return null;
  }

  return (
    <div
      className={`fixed bottom-16 sm:bottom-6 left-4 sm:left-6 z-40 transition-all duration-500 ease-out ${
        isVisible
          ? 'opacity-100 translate-y-0 pointer-events-auto'
          : 'opacity-0 translate-y-4 pointer-events-none'
      }`}
      role="status"
      aria-live="polite"
    >
      <div 
        onClick={onOpenCheckout}
        className="cursor-pointer max-w-[340px] bg-[#12141a]/95 backdrop-blur-md border border-white/15 rounded-2xl p-3.5 shadow-2xl hover:border-amber-400/40 transition-all flex items-start gap-3 text-neutral-100 group"
      >
        {/* Verified icon avatar */}
        <div className="w-10 h-10 rounded-xl bg-amber-400/15 border border-amber-400/30 text-amber-400 flex items-center justify-center shrink-0 mt-0.5 group-hover:scale-105 transition-transform">
          <ShoppingBag className="w-5 h-5" />
        </div>

        {/* Content body */}
        <div className="flex-1 min-w-0 pr-1">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-white truncate">
            <span className="font-bold text-amber-300">{currentSale.name}</span>
            <span className="text-neutral-400 font-normal">de</span>
            <span className="truncate">{currentSale.city}</span>
          </div>

          <p className="text-[11px] text-neutral-200 mt-0.5 leading-snug">
            acaba de comprar <strong className="text-white">{currentSale.plan}</strong>
          </p>

          <div className="flex items-center gap-1.5 mt-1 text-[10px] text-neutral-400">
            <CheckCircle className="w-3 h-3 text-emerald-400 shrink-0" />
            <span>Compra verificada</span>
            <span>·</span>
            <span className="text-neutral-400">{currentSale.timeAgo}</span>
          </div>
        </div>

        {/* Dismiss button */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            setIsVisible(false);
            setIsDismissed(true);
          }}
          className="text-neutral-400 hover:text-white p-1 rounded-md hover:bg-white/10 transition-colors shrink-0"
          aria-label="Cerrar notificación"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
