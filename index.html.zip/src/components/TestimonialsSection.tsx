import React from 'react';
import { Quote } from 'lucide-react';
import { TestimonialItem } from '../types';

export const TestimonialsSection: React.FC = () => {
  const testimonials: TestimonialItem[] = [
    {
      quote: '“Pensaba que no tenía disciplina. El diagnóstico mostró que estaba intentando trabajar en demasiadas ideas al mismo tiempo.”',
      name: 'Sofía Morales',
      role: 'Diseñadora Visual & Creadora de Contenido',
      discipline: '31 años · CDMX',
      location: 'Perfil detectado: Saturación de opciones',
    },
    {
      quote: '“En menos de quince minutos supe qué hacer con el proyecto que llevaba semanas evitando.”',
      name: 'David Rentería',
      role: 'Redactor & Escritor de No Ficción',
      discipline: '38 años · Bogotá',
      location: 'Perfil detectado: Fricción por inicio abstracto',
    },
    {
      quote: '“No me dio otra lista de consejos. Me indicó qué ejercicio usar según el bloqueo que tenía.”',
      name: 'Camila Vega',
      role: 'Ilustradora & Directora de Arte',
      discipline: '27 años · Santiago',
      location: 'Perfil detectado: Perfeccionismo crítico',
    },
  ];

  return (
    <section id="testimonios" className="w-full bg-[#ffffff] text-neutral-900 py-20 sm:py-28 border-b border-neutral-200">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-14 sm:mb-20">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-neutral-500 block mb-2">
            Prueba de Impacto Real
          </span>
          <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black text-neutral-900 tracking-tight">
            LO QUE ESTÁN DICIENDO
          </h2>
          <p className="mt-3 text-sm sm:text-base text-neutral-600 font-medium">
            Testimonios verificados de creadores que desbloquearon su práctica:
          </p>
        </div>

        {/* 3 Testimonials in clean, elegant editorial format */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, idx) => (
            <div
              key={idx}
              className="p-8 rounded-2xl bg-neutral-50 border border-neutral-200 flex flex-col justify-between space-y-6 hover:shadow-md transition-shadow"
            >
              <div className="space-y-4">
                <Quote className="w-8 h-8 text-amber-500/80 shrink-0" />
                <p className="text-base sm:text-lg font-medium text-neutral-900 leading-relaxed italic">
                  {t.quote}
                </p>
              </div>

              <div className="pt-4 border-t border-neutral-200 space-y-1">
                <div className="text-base font-bold text-neutral-900">
                  {t.name}
                </div>
                <div className="text-xs text-neutral-600 font-medium">
                  {t.role} · {t.discipline}
                </div>
                <div className="text-[11px] font-semibold text-amber-700 pt-1">
                  {t.location}
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
