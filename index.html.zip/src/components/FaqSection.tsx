import React, { useState } from 'react';
import { ChevronDown } from 'lucide-react';
import { FaqItem } from '../types';

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs: FaqItem[] = [
    {
      question: '¿Cómo accedo?',
      answer: 'Recibes un enlace inmediato después de completar el pago. Puedes abrirlo desde el celular o la computadora.',
    },
    {
      question: '¿Es un curso en video?',
      answer: 'No. Es una herramienta interactiva con diagnóstico, resultados personalizados y ejercicios prácticos.',
    },
    {
      question: '¿Cuánto tiempo toma ver resultados?',
      answer: 'El diagnóstico toma cerca de 12 minutos. Puedes recibir tu primera acción concreta en la misma sesión.',
    },
    {
      question: '¿Necesito experiencia previa?',
      answer: 'No. El sistema funciona tanto si estás empezando como si tienes proyectos creativos abandonados.',
    },
    {
      question: '¿Funciona en el celular?',
      answer: 'Sí. Está diseñado para completarse desde cualquier celular con conexión a internet.',
    },
    {
      question: '¿Qué pasa si tengo varios bloqueos?',
      answer: 'El diagnóstico identifica el patrón principal y te indica cuál atender primero.',
    },
    {
      question: '¿Sirve para cualquier disciplina?',
      answer: 'Puedes usarlo para escritura, música, diseño, arte, emprendimiento, investigación o proyectos personales.',
    },
    {
      question: '¿Me garantiza terminar mi proyecto?',
      answer: 'No promete resultados automáticos. Te entrega un punto de partida específico y un sistema para sostener la práctica.',
    },
    {
      question: '¿Incluye acompañamiento personal?',
      answer: 'No. Es una herramienta automatizada para que puedas evaluar tu situación y avanzar por tu cuenta.',
    },
  ];

  const toggleFaq = (index: number) => {
    setOpenIndex(prev => (prev === index ? null : index));
  };

  return (
    <section id="faq" className="w-full bg-[#0c0d11] text-neutral-100 py-20 sm:py-28 border-b border-white/10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-14 sm:mb-18">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-amber-400 block mb-2">
            Respuestas Claras
          </span>
          <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            PREGUNTAS FRECUENTES
          </h2>
          <p className="mt-3 text-sm sm:text-base text-neutral-400 font-medium">
            Todo lo que necesitas saber antes de iniciar tu diagnóstico interactivo:
          </p>
        </div>

        {/* Accordions */}
        <div className="space-y-3.5">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            return (
              <div
                key={idx}
                className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden transition-colors"
              >
                <button
                  type="button"
                  onClick={() => toggleFaq(idx)}
                  className="w-full p-5 sm:p-6 text-left flex items-center justify-between gap-4 font-bold text-base sm:text-lg text-white hover:text-amber-300 transition-colors"
                  aria-expanded={isOpen}
                >
                  <span className="leading-snug">{faq.question}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-amber-400 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-5 sm:px-6 pb-6 pt-1 text-sm sm:text-base text-neutral-300 font-normal leading-relaxed border-t border-white/5">
                    {faq.answer}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
