import React, { useState, useEffect } from 'react';
import { ArrowRight, Sparkles } from 'lucide-react';
import { Currency } from '../types';

interface StickyMobileBarProps {
  onOpenCheckout: () => void;
  currency: Currency;
}

export const StickyMobileBar: React.FC<StickyMobileBarProps> = ({ onOpenCheckout, currency }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      // Show only after scrolling down 400px (past hero)
      if (window.scrollY > 450) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 bg-[#0d0e12]/95 backdrop-blur-md border-t border-white/10 px-4 py-2.5 transition-all animate-in slide-in-from-bottom duration-200">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-3">
        <div className="truncate">
          <div className="text-xs font-bold text-white tracking-wide truncate">
            Radar Creativo
          </div>
          <div className="text-[11px] text-amber-400 font-bold truncate">
            {currency === 'MXN' ? '$250.00 MXN' : '$27.00 USD'} · Diagnóstico + 4 Bonos
          </div>
        </div>

        <button
          onClick={onOpenCheckout}
          className="shrink-0 px-4 py-2 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center gap-1.5 shadow-md"
        >
          <span>Comenzar</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
