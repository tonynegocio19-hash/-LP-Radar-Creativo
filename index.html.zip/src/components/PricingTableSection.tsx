import React from 'react';
import { ArrowRight, ShieldCheck, Check, Sparkles, Zap } from 'lucide-react';
import { Currency } from '../types';

interface PricingTableSectionProps {
  onOpenCheckout: () => void;
  currency: Currency;
  onToggleCurrency: (c: Currency) => void;
}

export const PricingTableSection: React.FC<PricingTableSectionProps> = ({
  onOpenCheckout,
  currency,
  onToggleCurrency,
}) => {
  const items = [
    { name: 'Radar Creativo', value: '$430' },
    { name: 'Test de Fricción', value: '$120' },
    { name: 'Generador de Primer Paso', value: '$150' },
    { name: 'Checklist de Sesión', value: '$120' },
    { name: 'Simulador de Bloqueo', value: '$150' },
  ];

  return (
    <section id="oferta" className="w-full bg-[#0a0b0e] text-neutral-100 py-20 sm:py-28 border-b border-white/10 relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        {/* Section Heading */}
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-amber-400 block mb-2">
            Desglose de Valor Integral
          </span>
          <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            RESUMEN DE TU ACCESO
          </h2>
          <p className="mt-3 text-sm sm:text-base text-neutral-400 font-medium">
            Todo lo que recibes al instante por una fracción de su valor por separado:
          </p>
        </div>

        {/* Currency Switcher */}
        <div className="flex justify-center mb-8">
          <div className="inline-flex p-1 bg-white/5 border border-white/10 rounded-xl text-xs font-bold">
            <button
              onClick={() => onToggleCurrency('MXN')}
              className={`px-4 py-1.5 rounded-lg transition-all ${
                currency === 'MXN' ? 'bg-amber-400 text-black shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              $250 MXN (México)
            </button>
            <button
              onClick={() => onToggleCurrency('USD')}
              className={`px-4 py-1.5 rounded-lg transition-all ${
                currency === 'USD' ? 'bg-amber-400 text-black shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              $27 USD (Internacional)
            </button>
          </div>
        </div>

        {/* The Exact Table Card */}
        <div className="rounded-2xl border border-white/15 bg-white/[0.02] shadow-2xl overflow-hidden backdrop-blur-sm">
          
          {/* Table Header */}
          <div className="grid grid-cols-12 px-6 sm:px-8 py-4 bg-white/5 border-b border-white/10 text-xs font-black uppercase tracking-widest text-neutral-300">
            <div className="col-span-8 sm:col-span-9">Componente</div>
            <div className="col-span-4 sm:col-span-3 text-right">Valor Original</div>
          </div>

          {/* Table Rows */}
          <div className="divide-y divide-white/5 text-sm sm:text-base">
            {items.map((row, idx) => (
              <div
                key={idx}
                className="grid grid-cols-12 px-6 sm:px-8 py-4 items-center hover:bg-white/[0.02] transition-colors"
              >
                <div className="col-span-8 sm:col-span-9 flex items-center gap-3">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="font-semibold text-neutral-200">{row.name}</span>
                </div>
                <div className="col-span-4 sm:col-span-3 text-right font-mono font-medium text-neutral-400">
                  {row.value}
                </div>
              </div>
            ))}
          </div>

          {/* Table Totals & Final Price */}
          <div className="p-6 sm:p-8 bg-neutral-900/80 border-t border-white/15 space-y-4">
            
            <div className="flex justify-between items-baseline text-sm sm:text-base text-neutral-400">
              <span className="font-bold uppercase tracking-wider">Valor Total</span>
              <span className="font-mono line-through font-semibold text-neutral-500">$14840</span>
            </div>

            <div className="flex justify-between items-baseline text-sm sm:text-base text-emerald-400">
              <span className="font-bold uppercase tracking-wider">Ahorro Aplicado</span>
              <span className="font-mono font-bold">Hoy ahorras $74 (98% dto)</span>
            </div>

            <div className="pt-4 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <span className="text-xs uppercase tracking-widest font-bold text-neutral-400 block">
                  Inversión Final Única
                </span>
                <div className="text-3xl sm:text-4xl font-black text-amber-400 tracking-tight">
                  {currency === 'MXN' ? 'Precio de Hoy: $250.00' : 'Precio de Hoy: $27.00'}
                </div>
                <span className="text-xs text-neutral-400 font-medium">
                  {currency === 'MXN' ? 'Equivalente a $27 USD · Pago único sin mensualidades' : 'Equivalente a $250 MXN · Pago único sin mensualidades'}
                </span>
              </div>

              {/* Exact CTA from copy */}
              <button
                onClick={onOpenCheckout}
                className="w-full sm:w-auto px-8 py-4 bg-amber-400 hover:bg-amber-300 text-black font-black text-sm uppercase tracking-wider rounded-xl transition-all shadow-xl hover:shadow-amber-400/25 flex items-center justify-center gap-3 whitespace-nowrap"
              >
                <span>EMPEZAR MI DIAGNÓSTICO</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

          </div>
        </div>

        {/* Security badges */}
        <div className="flex flex-wrap items-center justify-center gap-6 mt-6 text-xs text-neutral-400">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-400" /> Garantía de 7 días 100% incondicional
          </span>
          <span className="flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-amber-400" /> Acceso digital inmediato
          </span>
        </div>

      </div>
    </section>
  );
};
