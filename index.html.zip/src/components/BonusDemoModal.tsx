import React, { useState } from 'react';
import { X, CheckCircle2, ArrowRight, Play, Sparkles, RefreshCw } from 'lucide-react';

interface BonusDemoModalProps {
  bonusId: string | null;
  onClose: () => void;
  onOpenCheckout: () => void;
}

export const BonusDemoModal: React.FC<BonusDemoModalProps> = ({ bonusId, onClose, onOpenCheckout }) => {
  if (!bonusId) return null;

  // State for Bono 1: Quiz Fricción
  const [quizAnswer, setQuizAnswer] = useState<string | null>(null);
  const [frictionResult, setFrictionResult] = useState<string | null>(null);

  // State for Bono 2: Generador de Primer Paso
  const [ideaInput, setIdeaInput] = useState('');
  const [generatedStep, setGeneratedStep] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  // State for Bono 3: Checklist
  const [checkedTasks, setCheckedTasks] = useState<Record<string, boolean>>({
    'pre-1': true,
    'pre-2': false,
    'run-1': false,
    'run-2': false,
    'post-1': false,
  });

  // State for Bono 4: Simulador
  const [selectedScenario, setSelectedScenario] = useState<string | null>('saturacion');

  const handleRunQuiz = (choice: string) => {
    setQuizAnswer(choice);
    if (choice === 'perfect') {
      setFrictionResult('Perfil detectado: Perfeccionismo Crítico. Tu obstáculo no es la falta de calidad, sino el criterio de aprobación prematuro.');
    } else if (choice === 'satur') {
      setFrictionResult('Perfil detectado: Saturación de Opciones. Tienes exceso de referencias y necesitas reducir tu alcance a una sola variable.');
    } else if (choice === 'disp') {
      setFrictionResult('Perfil detectado: Dispersión Creativa. Tu cerebro busca la emoción del inicio y huye en la fase de pulido.');
    } else {
      setFrictionResult('Perfil detectado: Falta de Marco Temporal. El proyecto es demasiado abstracto y necesita un contenedor de 20 minutos.');
    }
  };

  const handleGenerateStep = () => {
    if (!ideaInput.trim()) return;
    setIsGenerating(true);
    setTimeout(() => {
      setIsGenerating(false);
      setGeneratedStep(
        `Para tu idea "${ideaInput.trim()}", tu sesión de 18 minutos hoy es: Escribe en una sola página de texto plano únicamente el esqueleto de 3 puntos esenciales. Prohibido buscar referencias visuales o corregir errores gramaticales hasta que suene la alarma.`
      );
    }, 450);
  };

  const toggleCheck = (id: string) => {
    setCheckedTasks(prev => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#131419] border border-white/10 rounded-2xl shadow-2xl p-6 sm:p-8 text-neutral-100 overflow-hidden max-h-[90vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4 shrink-0">
          <div>
            <span className="text-[11px] font-semibold tracking-widest uppercase text-amber-400">
              Vista previa interactiva
            </span>
            <h3 className="text-xl font-bold text-white mt-0.5">
              {bonusId === 'bono-1' && 'Bono 1: Test de Fricción'}
              {bonusId === 'bono-2' && 'Bono 2: Generador de Primer Paso'}
              {bonusId === 'bono-3' && 'Bono 3: Checklist de Sesión'}
              {bonusId === 'bono-4' && 'Bono 4: Simulador de Bloqueo'}
            </h3>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-white rounded-lg transition-colors hover:bg-white/5"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="py-6 overflow-y-auto space-y-6 flex-1 text-sm text-neutral-300">
          {bonusId === 'bono-1' && (
            <div className="space-y-5">
              <p className="text-neutral-300 leading-relaxed font-normal">
                Haz clic en la frase que mejor describe lo que sientes al sentarte a trabajar en tu proyecto:
              </p>
              
              <div className="space-y-2.5">
                {[
                  { id: 'perfect', label: '“Siento que lo que estoy haciendo no tiene el nivel que debería y lo borro varias veces.”' },
                  { id: 'satur', label: '“Tengo 15 ideas abiertas al mismo tiempo y no sé cuál vale la pena continuar.”' },
                  { id: 'disp', label: '“Apenas empieza la parte difícil, abro redes sociales o me pongo a investigar otra cosa.”' },
                  { id: 'struct', label: '“Tengo ganas de avanzar, pero el proyecto es tan gigante que no sé cuál es el paso 1.”' },
                ].map(opt => (
                  <button
                    key={opt.id}
                    onClick={() => handleRunQuiz(opt.id)}
                    className={`w-full text-left p-3.5 rounded-xl border transition-all text-xs sm:text-sm font-medium ${
                      quizAnswer === opt.id 
                        ? 'border-amber-400 bg-amber-400/10 text-white' 
                        : 'border-white/10 bg-white/[0.02] hover:bg-white/[0.06] text-neutral-300'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              {frictionResult && (
                <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-400/30 text-amber-200 text-xs sm:text-sm space-y-1">
                  <span className="font-bold uppercase tracking-wider block text-[11px] text-amber-400">
                    Diagnóstico instantáneo
                  </span>
                  <p>{frictionResult}</p>
                </div>
              )}
            </div>
          )}

          {bonusId === 'bono-2' && (
            <div className="space-y-5">
              <p className="text-neutral-300 leading-relaxed">
                Ingresa cualquier proyecto o idea que lleves postergando para simular cómo el generador extrae una acción concreta de 18 a 20 minutos:
              </p>

              <div className="space-y-3">
                <input
                  type="text"
                  placeholder="Ej: Escribir el primer capítulo de mi novela / Rediseñar mi web"
                  value={ideaInput}
                  onChange={e => setIdeaInput(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-black/40 border border-white/15 text-white placeholder-neutral-500 text-sm focus:outline-none focus:border-amber-400"
                />
                <button
                  onClick={handleGenerateStep}
                  disabled={!ideaInput.trim() || isGenerating}
                  className="w-full py-3 px-4 bg-amber-400 hover:bg-amber-300 disabled:opacity-50 text-black font-bold text-xs uppercase tracking-wider rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  {isGenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  Generar Acción de 20 Minutos
                </button>
              </div>

              {generatedStep && (
                <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-400/30 text-emerald-100 text-xs sm:text-sm space-y-2">
                  <span className="font-bold uppercase tracking-wider block text-[11px] text-emerald-400">
                    Ruta de micro-acción asignada
                  </span>
                  <p className="leading-relaxed">{generatedStep}</p>
                </div>
              )}
            </div>
          )}

          {bonusId === 'bono-3' && (
            <div className="space-y-4">
              <p className="text-neutral-300 text-xs sm:text-sm">
                Un protocolo visual interactivo para no dispersarte antes, durante ni después de crear:
              </p>

              <div className="space-y-3">
                <div className="border border-white/10 rounded-xl p-3.5 bg-white/[0.02]">
                  <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
                    Fase 01: Preparación (3 min)
                  </h4>
                  <div className="space-y-2">
                    {[
                      { id: 'pre-1', text: 'Cerrar todas las pestañas de referencia que no sean esenciales.' },
                      { id: 'pre-2', text: 'Definir el objetivo único de la sesión en una sola oración visible.' },
                    ].map(item => (
                      <label key={item.id} className="flex items-start gap-2.5 cursor-pointer text-xs sm:text-sm text-neutral-300">
                        <input
                          type="checkbox"
                          checked={checkedTasks[item.id] || false}
                          onChange={() => toggleCheck(item.id)}
                          className="mt-0.5 rounded border-white/20 accent-amber-400"
                        />
                        <span className={checkedTasks[item.id] ? 'line-through text-neutral-500' : ''}>
                          {item.text}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="border border-white/10 rounded-xl p-3.5 bg-white/[0.02]">
                  <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
                    Fase 02: Sprint de Foco (15 min)
                  </h4>
                  <div className="space-y-2">
                    {[
                      { id: 'run-1', text: 'Trabajar sin juzgar calidad: solo generar volumen y avance bruto.' },
                      { id: 'run-2', text: 'Si aparece una duda, anotarla en el margen sin detener la escritura/diseño.' },
                    ].map(item => (
                      <label key={item.id} className="flex items-start gap-2.5 cursor-pointer text-xs sm:text-sm text-neutral-300">
                        <input
                          type="checkbox"
                          checked={checkedTasks[item.id] || false}
                          onChange={() => toggleCheck(item.id)}
                          className="mt-0.5 rounded border-white/20 accent-amber-400"
                        />
                        <span className={checkedTasks[item.id] ? 'line-through text-neutral-500' : ''}>
                          {item.text}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="border border-white/10 rounded-xl p-3.5 bg-white/[0.02]">
                  <h4 className="text-xs font-bold text-amber-400 uppercase tracking-wider mb-2">
                    Fase 03: Cierre & Anclaje (2 min)
                  </h4>
                  <label className="flex items-start gap-2.5 cursor-pointer text-xs sm:text-sm text-neutral-300">
                    <input
                      type="checkbox"
                      checked={checkedTasks['post-1'] || false}
                      onChange={() => toggleCheck('post-1')}
                      className="mt-0.5 rounded border-white/20 accent-amber-400"
                    />
                    <span className={checkedTasks['post-1'] ? 'line-through text-neutral-500' : ''}>
                      Anotar la primera frase o elemento con el que comenzarás en la siguiente sesión.
                    </span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {bonusId === 'bono-4' && (
            <div className="space-y-4">
              <p className="text-neutral-300">
                Selecciona la situación típica de tus días difíciles para ver la alternativa práctica inmediata:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {[
                  { id: 'saturacion', label: 'Cansancio mental' },
                  { id: 'duda', label: 'Duda paralizante' },
                  { id: 'tiempo', label: 'Tengo solo 10 min' },
                ].map(tab => (
                  <button
                    key={tab.id}
                    onClick={() => setSelectedScenario(tab.id)}
                    className={`py-2 px-3 text-xs font-semibold rounded-lg border transition-all ${
                      selectedScenario === tab.id
                        ? 'border-amber-400 bg-amber-400 text-black'
                        : 'border-white/10 bg-white/5 text-neutral-300 hover:bg-white/10'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="p-4 rounded-xl bg-white/[0.03] border border-white/10 space-y-2">
                {selectedScenario === 'saturacion' && (
                  <>
                    <h5 className="font-bold text-white text-xs uppercase tracking-wide">
                      Protocolo: Sesión de Baja Carga Cognitiva
                    </h5>
                    <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
                      Hoy no tomes decisiones estructurales. Realiza una tarea de mantenimiento: ordena tus referencias, titula tus bocetos o transcribe notas dispersas en un documento limpio. Mantienes el impulso sin quemar energía.
                    </p>
                  </>
                )}
                {selectedScenario === 'duda' && (
                  <>
                    <h5 className="font-bold text-white text-xs uppercase tracking-wide">
                      Protocolo: El Borrador Sacrificable
                    </h5>
                    <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
                      Crea un archivo nuevo titulado "Borrador Inservible". Date permiso expreso de escribir o diseñar la peor versión posible durante 10 minutos. Eliminar la expectativa de excelencia disuelve la parálisis en 180 segundos.
                    </p>
                  </>
                )}
                {selectedScenario === 'tiempo' && (
                  <>
                    <h5 className="font-bold text-white text-xs uppercase tracking-wide">
                      Protocolo: Micro-Inoculación
                    </h5>
                    <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed">
                      No intentes completar un bloque. Abre el archivo, haz un solo ajuste quirúrgico (una frase, un recorte, un ajuste de color) y ciérralo. Tu mente subconsciente continuará trabajando en la solución durante el resto del día.
                    </p>
                  </>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer / CTA inside modal */}
        <div className="border-t border-white/10 pt-4 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <span className="text-xs text-neutral-400">
            Incluido gratis en tu acceso de hoy
          </span>
          <button
            onClick={() => {
              onClose();
              onOpenCheckout();
            }}
            className="w-full sm:w-auto px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-black font-bold text-xs uppercase tracking-wider rounded-lg transition-colors flex items-center justify-center gap-2"
          >
            <span>Obtener con Radar Creativo</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
