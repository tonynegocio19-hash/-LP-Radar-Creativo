import React from 'react';
import { ShieldCheck, CheckCircle2, ArrowRight } from 'lucide-react';

interface GuaranteeSectionProps {
  onOpenCheckout: () => void;
}

export const GuaranteeSection: React.FC<GuaranteeSectionProps> = ({ onOpenCheckout }) => {
  return (
    <section id="garantia" className="w-full bg-[#fbf9f4] text-[#121316] py-20 sm:py-28 border-b border-[#e8e2d5]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        <div className="p-8 sm:p-12 rounded-3xl bg-white border border-[#e2dcce] shadow-xl text-center space-y-6 relative overflow-hidden">
          
          {/* Subtle icon badge */}
          <div className="w-16 h-16 rounded-2xl bg-amber-400/20 text-neutral-900 border border-amber-400/40 flex items-center justify-center mx-auto">
            <ShieldCheck className="w-9 h-9 text-neutral-900" />
          </div>

          <div className="space-y-3 max-w-2xl mx-auto">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-neutral-500 block">
              Tranquilidad Total
            </span>
            <h2 className="text-2xl sm:text-4xl font-black text-neutral-900 tracking-tight">
              GARANTÍA INCONDICIONAL DE 7 DÍAS
            </h2>
          </div>

          <div className="space-y-4 max-w-2xl mx-auto text-base sm:text-lg text-neutral-700 leading-relaxed font-normal">
            <p>
              Prueba Radar Creativo y revisa si el diagnóstico te ayuda a entender tu bloqueo y elegir una práctica útil.
            </p>
            <p className="font-semibold text-neutral-900">
              Si sientes que no es para ti, te devolvemos tu dinero. Sin preguntas incómodas. Sin trámites.
            </p>
          </div>

          {/* CTA from copy */}
          <div className="pt-4">
            <button
              onClick={onOpenCheckout}
              className="px-8 py-4 bg-neutral-900 hover:bg-neutral-800 text-white font-black text-xs sm:text-sm uppercase tracking-wider rounded-xl transition-all shadow-md hover:shadow-lg inline-flex items-center gap-3"
            >
              <span>PROBAR SIN RIESGO</span>
              <ArrowRight className="w-4 h-4 text-amber-300" />
            </button>
          </div>

          <div className="pt-2 text-xs text-neutral-500 font-medium">
            Respaldado por política de reembolso inmediato en menos de 24 horas.
          </div>

        </div>

      </div>
    </section>
  );
};
