import React, { useState } from 'react';
import { ArrowRight, Clock, Flame, ShieldAlert, Sparkles, Sliders } from 'lucide-react';

interface CostOfWaitingSectionProps {
  onOpenCheckout: () => void;
}

export const CostOfWaitingSection: React.FC<CostOfWaitingSectionProps> = ({ onOpenCheckout }) => {
  const [weeksDelayed, setWeeksDelayed] = useState<number>(4);

  // Dynamic friction calculations based on weeks delayed
  const daysOfNoise = weeksDelayed * 7;
  const hoursRuminating = weeksDelayed * 14;
  const energyLossPercent = Math.min(95, 30 + weeksDelayed * 8);

  return (
    <section className="w-full bg-[#15161c] text-neutral-100 py-20 sm:py-32 border-b border-white/10 relative overflow-hidden">
      {/* Editorial architectural grid lines */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:4rem_4rem] pointer-events-none" />

      {/* Ambient subtle warm flare */}
      <div className="absolute top-1/2 left-0 -translate-y-1/2 w-96 h-96 bg-amber-500/10 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 relative z-10">
        
        {/* Section Header: Swiss / Avant-Garde Editorial Style */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-10 border-b border-white/15">
          <div className="max-w-2xl space-y-3">
            <div className="inline-flex items-center gap-2 text-[11px] font-black uppercase tracking-[0.25em] text-amber-400">
              <span className="w-2 h-2 bg-amber-400 rounded-none rotate-45" />
              <span>Auditoría de Inercia</span>
            </div>
            <h2 
              style={{ marginLeft: '0px', paddingLeft: '8px', paddingRight: '0px', paddingTop: '0px', paddingBottom: '0px', marginRight: '-273px' }}
              className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-[1.05]"
            >
              SEGUIR ESPERANDO TAMBIÉN TIENE UN COSTO
            </h2>
          </div>

          <div className="text-xs font-mono text-neutral-400 uppercase tracking-widest shrink-0">
            [FRICCIÓN CREATIVA ACUMULADA]
          </div>
        </div>

        {/* Bespoke Editorial Grid: The 3 Core Copy Statements */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-0 border border-white/15 divide-y md:divide-y-0 md:divide-x divide-white/15 bg-white/[0.02] backdrop-blur-sm">
          
          {/* Card 01 */}
          <div className="p-8 sm:p-10 flex flex-col justify-between space-y-8 group hover:bg-white/[0.04] transition-colors relative">
            <div className="space-y-6">
              <div className="flex items-center justify-between text-xs font-mono text-neutral-400">
                <span className="text-amber-400 font-bold text-lg">/ 01</span>
                <span>DESORDEN COGNITIVO</span>
              </div>
              <p className="text-lg sm:text-xl font-semibold text-white leading-relaxed tracking-tight">
                Tus ideas no se ordenan solas mientras acumulas pestañas, notas y proyectos incompletos.
              </p>
            </div>
            <div className="pt-6 border-t border-white/10 text-xs text-neutral-400 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-neutral-500 rounded-full" />
              <span>La acumulación pasiva consume atención silenciosa</span>
            </div>
          </div>

          {/* Card 02 */}
          <div className="p-8 sm:p-10 flex flex-col justify-between space-y-8 group hover:bg-white/[0.04] transition-colors relative">
            <div className="space-y-6">
              <div className="flex items-center justify-between text-xs font-mono text-neutral-400">
                <span className="text-amber-400 font-bold text-lg">/ 02</span>
                <span>RESISTENCIA CRECIENTE</span>
              </div>
              <p className="text-lg sm:text-xl font-semibold text-white leading-relaxed tracking-tight">
                Cada semana que pospones, el bloqueo gana fuerza y empezar vuelve a sentirse más pesado.
              </p>
            </div>
            <div className="pt-6 border-t border-white/10 text-xs text-neutral-400 flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-amber-400 rounded-full" />
              <span>El umbral de fricción aumenta un 25% por ciclo</span>
            </div>
          </div>

          {/* Card 03: Highlighted Outcome */}
          <div className="p-8 sm:p-10 flex flex-col justify-between space-y-8 bg-amber-400/5 hover:bg-amber-400/10 transition-colors relative">
            <div className="space-y-6">
              <div className="flex items-center justify-between text-xs font-mono text-amber-300">
                <span className="text-amber-400 font-bold text-lg">/ 03</span>
                <span>EL PUNTO DE QUIEBRE</span>
              </div>
              <p className="text-lg sm:text-xl font-bold text-amber-100 leading-relaxed tracking-tight">
                Puedes seguir buscando otra técnica o identificar hoy qué te frena y hacer una sesión breve con un propósito concreto.
              </p>
            </div>
            <div className="pt-6 border-t border-amber-400/20 text-xs text-amber-300 font-medium flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-amber-400 rounded-full" />
              <span>La claridad proviene de la acción dirigida, no de esperar</span>
            </div>
          </div>

        </div>

        {/* Unique Bespoke Interactive Element: Calculadora Visual de Inercia */}
        <div className="mt-12 p-8 sm:p-10 rounded-2xl bg-[#1c1e27] border border-white/15 space-y-8 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-[11px] font-mono uppercase tracking-widest text-amber-400 block mb-1">
                Simulador de Impacto Real
              </span>
              <h3 className="text-xl sm:text-2xl font-black text-white">
                ¿Cuánto tiempo llevas postergando ese proyecto?
              </h3>
            </div>
            <div className="text-right">
              <span className="text-3xl sm:text-4xl font-mono font-black text-amber-400">
                {weeksDelayed} {weeksDelayed === 1 ? 'semana' : 'semanas'}
              </span>
            </div>
          </div>

          {/* Slider input */}
          <div className="space-y-2">
            <input
              type="range"
              min={1}
              max={16}
              value={weeksDelayed}
              onChange={e => setWeeksDelayed(Number(e.target.value))}
              className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-400 focus:outline-none"
              aria-label="Semanas posponiendo el proyecto"
            />
            <div className="flex justify-between text-[11px] font-mono text-neutral-400">
              <span>1 semana</span>
              <span>4 semanas</span>
              <span>8 semanas</span>
              <span>16 semanas</span>
            </div>
          </div>

          {/* Interactive Metric Gauges */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-1">
              <div className="text-[11px] font-mono text-neutral-400 uppercase">Ruido Mental Acumulado</div>
              <div className="text-2xl sm:text-3xl font-mono font-bold text-white">~{daysOfNoise} días</div>
              <p className="text-[11px] text-neutral-400">Pensando en lo que no has terminado</p>
            </div>

            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-1">
              <div className="text-[11px] font-mono text-neutral-400 uppercase">Tiempo Rumiante Perdido</div>
              <div className="text-2xl sm:text-3xl font-mono font-bold text-amber-400">~{hoursRuminating} horas</div>
              <p className="text-[11px] text-neutral-400">En micro-distracciones y culpa</p>
            </div>

            <div className="p-4 rounded-xl bg-black/40 border border-white/10 space-y-1">
              <div className="text-[11px] font-mono text-neutral-400 uppercase">Antídoto Inmediato</div>
              <div className="text-2xl sm:text-3xl font-mono font-bold text-emerald-400">12 min</div>
              <p className="text-[11px] text-neutral-400">Diagnóstico para destrabar la ruta hoy</p>
            </div>
          </div>
        </div>

        {/* CTA Banner */}
        <div className="mt-14 text-center space-y-4">
          <button
            onClick={onOpenCheckout}
            className="w-full sm:w-auto px-10 py-5 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs sm:text-sm uppercase tracking-widest rounded-xl transition-all shadow-2xl hover:shadow-amber-400/25 inline-flex items-center justify-center gap-3 group"
          >
            <span>IDENTIFICAR LO QUE ME ESTÁ FRENANDO</span>
            <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
          </button>
          
          <div className="text-xs font-medium text-neutral-400 flex items-center justify-center gap-2">
            <span>Sesión interactiva guiada</span>
            <span>·</span>
            <span>Sin teoría innecesaria</span>
            <span>·</span>
            <span>Solución ajustada a tu tiempo</span>
          </div>
        </div>

      </div>
    </section>
  );
};
