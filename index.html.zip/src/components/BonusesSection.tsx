import React from 'react';
import { Sparkles, Eye, CheckCircle2, ArrowRight } from 'lucide-react';
import { BonusItem } from '../types';

interface BonusesSectionProps {
  onOpenBonusDemo: (bonusId: string) => void;
  onOpenCheckout: () => void;
}

export const BonusesSection: React.FC<BonusesSectionProps> = ({ onOpenBonusDemo, onOpenCheckout }) => {
  const bonuses: BonusItem[] = [
    {
      id: 'bono-1',
      badge: 'Bono 1',
      title: 'TEST DE FRICCIÓN',
      subtitle: 'Descubre por qué te detienes justo cuando empieza lo difícil',
      description: 'Quiz interactivo que distingue entre perfeccionismo, saturación, dispersión y falta de estructura.',
      value: '$120',
      interactiveLabel: 'Probar test de fricción',
    },
    {
      id: 'bono-2',
      badge: 'Bono 2',
      title: 'GENERADOR DE PRIMER PASO',
      subtitle: 'Deja de preguntarte por dónde empezar',
      description: 'Escribes tu idea y recibes una acción concreta de menos de 20 minutos para ponerla en movimiento.',
      value: '$150',
      interactiveLabel: 'Probar generador de 20 min',
    },
    {
      id: 'bono-3',
      badge: 'Bono 3',
      title: 'CHECKLIST DE SESIÓN',
      subtitle: 'Crea aunque tengas poco tiempo',
      description: 'Checklist interactivo para preparar, ejecutar y cerrar una sesión creativa sin perderte en detalles.',
      value: '$120',
      interactiveLabel: 'Explorar checklist',
    },
    {
      id: 'bono-4',
      badge: 'Bono 4',
      title: 'SIMULADOR DE BLOQUEO',
      subtitle: 'Ten una respuesta lista para los días malos',
      description: 'Seleccionas lo que está ocurriendo y recibes una alternativa práctica para continuar sin abandonar el proyecto.',
      value: '$150',
      interactiveLabel: 'Abrir simulador',
    },
  ];

  return (
    <section id="bonos" className="w-full bg-[#101216] text-neutral-100 py-20 sm:py-28 border-b border-white/10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 sm:mb-20">
          <span className="text-xs font-bold uppercase tracking-[0.2em] text-amber-400 block mb-2">
            Herramientas Prácticas Adicionales
          </span>
          <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight">
            BONOS INTERACTIVOS INCLUIDOS
          </h2>
          <p className="mt-3 text-sm sm:text-base text-neutral-400 font-medium">
            Sin costo adicional al activar tu Radar Creativo hoy. Toca en cada herramienta para probar una demostración interactiva:
          </p>
        </div>

        {/* 2x2 Grid of Bonuses */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8">
          {bonuses.map(bonus => (
            <div
              key={bonus.id}
              className="p-7 sm:p-8 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-amber-400/40 transition-all flex flex-col justify-between space-y-6 group"
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-widest text-amber-400 border border-amber-400/30 px-2.5 py-1 rounded bg-amber-400/10">
                    {bonus.badge}
                  </span>
                  <span className="text-xs font-semibold text-neutral-400 line-through">
                    Valor: {bonus.value}
                  </span>
                </div>

                <div>
                  <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight">
                    {bonus.title}
                  </h3>
                  <h4 className="text-sm sm:text-base font-bold text-amber-200 mt-1">
                    {bonus.subtitle}
                  </h4>
                </div>

                <p className="text-sm text-neutral-300 leading-relaxed font-normal">
                  {bonus.description}
                </p>
              </div>

              {/* Action Buttons: Demo Preview & Included tag */}
              <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => onOpenBonusDemo(bonus.id)}
                  className="px-3.5 py-2 rounded-lg bg-white/5 hover:bg-white/15 text-xs font-bold text-white transition-colors flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5 text-amber-400" />
                  <span>{bonus.interactiveLabel}</span>
                </button>

                <span className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Gratis con tu acceso
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Global CTA below bonuses */}
        <div className="mt-14 text-center">
          <button
            onClick={onOpenCheckout}
            className="px-8 py-4 bg-amber-400 hover:bg-amber-300 text-black font-black text-xs sm:text-sm uppercase tracking-wider rounded-xl transition-all shadow-xl hover:shadow-amber-400/20 inline-flex items-center gap-2"
          >
            <span>QUIERO EL RADAR Y LOS 4 BONOS</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

      </div>
    </section>
  );
};
