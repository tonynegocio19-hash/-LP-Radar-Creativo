import React from 'react';
import { ShieldCheck, Lock } from 'lucide-react';

interface FooterProps {
  onOpenHotmartConfig?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenHotmartConfig }) => {
  return (
    <footer className="w-full bg-[#08090b] text-neutral-400 py-12 border-t border-white/10 text-xs">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-8">
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-6 border-b border-white/10">
          <div>
            <span className="text-base font-black uppercase tracking-widest text-white">
              RADAR CREATIVO
            </span>
            <p className="text-xs text-neutral-400 mt-1 max-w-sm">
              Diagnóstico interactivo que detecta tu bloqueo creativo y genera una ruta de práctica ajustada a tu tiempo.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-6 text-xs text-neutral-400">
            <a href="#para-quien" className="hover:text-white transition-colors">¿Es para mí?</a>
            <a href="#metodo" className="hover:text-white transition-colors">El Método</a>
            <a href="#bonos" className="hover:text-white transition-colors">Bonos</a>
            <a href="#testimonios" className="hover:text-white transition-colors">Opiniones</a>
            <a href="#garantia" className="hover:text-white transition-colors">Garantía</a>
            <a href="#faq" className="hover:text-white transition-colors">Preguntas</a>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-400">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-neutral-400" /> Transacción Segura SSL 256-Bit
            </span>
            <span>·</span>
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-neutral-400" /> Garantía de 7 Días
            </span>
            {onOpenHotmartConfig && (
              <>
                <span>·</span>
                <button
                  type="button"
                  onClick={onOpenHotmartConfig}
                  className="text-amber-400 hover:text-amber-300 underline font-semibold transition-colors"
                >
                  Configurar Checkout Hotmart
                </button>
              </>
            )}
          </div>

          <div>
            © {new Date().getFullYear()} Radar Creativo. Todos los derechos reservados.
          </div>
        </div>

      </div>
    </footer>
  );
};
