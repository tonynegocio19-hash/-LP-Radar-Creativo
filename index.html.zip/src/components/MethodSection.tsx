import React from 'react';
import { ArrowRight, CheckCircle2, Sliders, Cpu, Compass } from 'lucide-react';

interface MethodSectionProps {
  onOpenCheckout: () => void;
}

export const MethodSection: React.FC<MethodSectionProps> = ({ onOpenCheckout }) => {
  const steps = [
    {
      num: '01',
      title: 'PASO 01: RESPONDES',
      desc: 'Describe tus proyectos, hábitos y bloqueos en el diagnóstico interactivo.',
      tag: 'Toma ~12 minutos',
    },
    {
      num: '02',
      title: 'PASO 02: EL SISTEMA DETECTA',
      desc: 'Compara tus respuestas y encuentra el patrón que está frenando tu producción.',
      tag: 'Perfil de Fricción',
    },
    {
      num: '03',
      title: 'PASO 03: RECIBES',
      desc: 'Obtienes un plan personalizado con sesiones, ejercicios y una primera acción para hoy.',
      tag: 'Acción en menos de 20 min',
    },
  ];

  const mapBullets = [
    'Respondes preguntas sobre tus hábitos, proyectos y obstáculos.',
    'El sistema identifica tu Perfil de Fricción y selecciona las prácticas que mejor encajan contigo.',
    'Recibes una ruta concreta para crear esta semana. Sin teoría interminable. Sin depender de inspiración. Sin copiar el método de otra persona.',
  ];

  return (
    <section id="metodo" className="w-full bg-[#0c1017] text-neutral-100 py-20 sm:py-28 border-b border-white/10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 space-y-20 sm:space-y-28">
        
        {/* Sub-block A: Mapa de Práctica Dirigida */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
          
          {/* Left Column: Copy */}
          <div className="lg:col-span-7 space-y-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-[0.2em] text-amber-400 block mb-2">
                Estructura Operativa
              </span>
              <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
                Cómo Funciona: Mapa de Práctica Dirigida
              </h2>
              <p className="mt-3 text-lg sm:text-xl font-medium text-neutral-300">
                Un plan que empieza desde tu bloqueo real
              </p>
            </div>

            <ul className="space-y-4 pt-2">
              {mapBullets.map((bullet, idx) => (
                <li key={idx} className="flex items-start gap-3.5">
                  <div className="mt-1 w-5 h-5 rounded-full bg-amber-400/20 text-amber-400 flex items-center justify-center shrink-0">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span className="text-sm sm:text-base text-neutral-200 leading-relaxed font-normal">
                    {bullet}
                  </span>
                </li>
              ))}
            </ul>

            <div className="pt-2">
              <button
                onClick={onOpenCheckout}
                className="px-6 py-3.5 bg-white hover:bg-neutral-200 text-black font-extrabold text-xs sm:text-sm uppercase tracking-wider rounded-xl transition-colors flex items-center gap-2"
              >
                <span>Generar mi Mapa Personalizado</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right Column: Tablet Preview Mockup */}
          <div className="lg:col-span-5">
            <div className="relative rounded-2xl overflow-hidden border border-white/15 bg-black/60 shadow-2xl p-2 sm:p-3">
              <img
                src="/src/assets/images/diagnostic_interface_preview_1793863718576.jpg"
                alt="Pantalla interactiva del diagnóstico de Radar Creativo en tableta"
                referrerPolicy="no-referrer"
                className="w-full h-auto rounded-xl object-cover"
              />
              <div className="p-3 text-center text-xs text-neutral-400">
                Interfaz interactiva 100% responsiva para celular, tablet y computadora.
              </div>
            </div>
          </div>

        </div>

        {/* Sub-block B: CÓMO FUNCIONA EL MÉTODO (3 Pasos Simples) */}
        <div className="pt-8 border-t border-white/10">
          <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
            <span className="text-xs font-bold uppercase tracking-[0.2em] text-neutral-400 block mb-2">
              Proceso de 3 Etapas
            </span>
            <h3 className="text-2xl sm:text-4xl font-black text-white tracking-tight">
              CÓMO FUNCIONA EL MÉTODO
            </h3>
            <p className="mt-3 text-sm sm:text-base text-neutral-300 font-medium">
              3 pasos simples para pasar de ideas acumuladas a práctica real
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            {steps.map(step => (
              <div 
                key={step.num}
                className="p-7 sm:p-8 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-amber-400/40 transition-colors flex flex-col justify-between space-y-6"
              >
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-3xl sm:text-4xl font-black text-amber-400 font-mono tracking-tight">
                      {step.num}
                    </span>
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-neutral-400 border border-white/10 px-2 py-0.5 rounded">
                      {step.tag}
                    </span>
                  </div>

                  <h4 className="text-base sm:text-lg font-bold text-white tracking-tight">
                    {step.title}
                  </h4>

                  <p className="text-sm text-neutral-300 leading-relaxed font-normal">
                    {step.desc}
                  </p>
                </div>

                <div className="text-[11px] font-medium text-neutral-500 uppercase tracking-widest pt-4 border-t border-white/5">
                  Sin fricción ni pérdida de tiempo
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
