import React, { useState, useEffect } from 'react';
import { X, ExternalLink, Check, Link2, HelpCircle, Save, Sparkles } from 'lucide-react';
import { getHotmartUrl, saveHotmartUrl } from '../config/checkout';

interface HotmartConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveSuccess?: () => void;
}

export const HotmartConfigModal: React.FC<HotmartConfigModalProps> = ({ isOpen, onClose, onSaveSuccess }) => {
  const [generalUrl, setGeneralUrl] = useState('');
  const [mxnUrl, setMxnUrl] = useState('');
  const [usdUrl, setUsdUrl] = useState('');
  const [useSeparateCurrencies, setUseSeparateCurrencies] = useState(false);
  const [openInNewTab, setOpenInNewTab] = useState(true);
  const [savedNotification, setSavedNotification] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setGeneralUrl(localStorage.getItem('rc_hotmart_checkout_url') || '');
      setMxnUrl(localStorage.getItem('rc_hotmart_checkout_url_mxn') || '');
      setUsdUrl(localStorage.getItem('rc_hotmart_checkout_url_usd') || '');
      setOpenInNewTab(localStorage.getItem('rc_hotmart_open_new_tab') !== 'false');
      
      const hasSpecific = Boolean(
        localStorage.getItem('rc_hotmart_checkout_url_mxn') || 
        localStorage.getItem('rc_hotmart_checkout_url_usd')
      );
      setUseSeparateCurrencies(hasSpecific);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    saveHotmartUrl(generalUrl);

    if (useSeparateCurrencies) {
      saveHotmartUrl(mxnUrl, 'MXN');
      saveHotmartUrl(usdUrl, 'USD');
    } else {
      localStorage.removeItem('rc_hotmart_checkout_url_mxn');
      localStorage.removeItem('rc_hotmart_checkout_url_usd');
    }

    localStorage.setItem('rc_hotmart_open_new_tab', openInNewTab ? 'true' : 'false');

    setSavedNotification(true);
    setTimeout(() => {
      setSavedNotification(false);
      if (onSaveSuccess) onSaveSuccess();
      onClose();
    }, 900);
  };

  const testLink = (url: string) => {
    if (!url || !url.trim()) return;
    const finalUrl = url.trim().startsWith('http') ? url.trim() : `https://${url.trim()}`;
    window.open(finalUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-lg bg-[#111318] border border-white/15 rounded-2xl shadow-2xl p-6 sm:p-8 text-neutral-100 overflow-hidden flex flex-col max-h-[90vh]"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-400 text-black flex items-center justify-center font-bold">
              <Link2 className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">
                Configurar Enlace de Hotmart
              </h3>
              <p className="text-xs text-neutral-400">
                Conecta tu checkout para cobrar directamente con tu cuenta
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg transition-colors hover:bg-white/10"
            aria-label="Cerrar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSave} className="py-5 space-y-5 overflow-y-auto flex-1 pr-1 text-xs sm:text-sm">
          
          {/* Main URL field */}
          <div className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-neutral-300">
              Enlace de Checkout Principal (Hotmart)
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                placeholder="https://pay.hotmart.com/TU_CODIGO_AQUI"
                value={generalUrl}
                onChange={e => setGeneralUrl(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl bg-black/50 border border-white/15 text-white placeholder-neutral-500 font-mono text-xs focus:outline-none focus:border-amber-400"
              />
              {generalUrl && (
                <button
                  type="button"
                  onClick={() => testLink(generalUrl)}
                  title="Probar enlace en nueva pestaña"
                  className="p-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-neutral-300 hover:text-white transition-colors shrink-0"
                >
                  <ExternalLink className="w-4 h-4" />
                </button>
              )}
            </div>
            <p className="text-[11px] text-neutral-400">
              Todos los botones de compra dirigirán a este checkout automáticamente.
            </p>
          </div>

          {/* Toggle for currency-specific links */}
          <div className="pt-2 border-t border-white/10">
            <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-neutral-300 font-medium">
              <input
                type="checkbox"
                checked={useSeparateCurrencies}
                onChange={e => setUseSeparateCurrencies(e.target.checked)}
                className="rounded accent-amber-400"
              />
              <span>Tengo enlaces de Hotmart distintos para MXN ($250) y USD ($27)</span>
            </label>
          </div>

          {useSeparateCurrencies && (
            <div className="space-y-3 p-3.5 rounded-xl bg-white/[0.02] border border-white/10">
              <div className="space-y-1.5">
                <label className="block text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                  Link para oferta en México ($250.00 MXN)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="https://pay.hotmart.com/OFERTA_MXN"
                    value={mxnUrl}
                    onChange={e => setMxnUrl(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-white placeholder-neutral-500 font-mono text-xs focus:outline-none focus:border-amber-400"
                  />
                  {mxnUrl && (
                    <button
                      type="button"
                      onClick={() => testLink(mxnUrl)}
                      className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-neutral-300 shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="block text-[11px] font-bold text-amber-400 uppercase tracking-wider">
                  Link para oferta Internacional ($27.00 USD)
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="https://pay.hotmart.com/OFERTA_USD"
                    value={usdUrl}
                    onChange={e => setUsdUrl(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-black/40 border border-white/10 text-white placeholder-neutral-500 font-mono text-xs focus:outline-none focus:border-amber-400"
                  />
                  {usdUrl && (
                    <button
                      type="button"
                      onClick={() => testLink(usdUrl)}
                      className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-neutral-300 shrink-0"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* New Tab Option */}
          <div className="space-y-2 pt-1">
            <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-neutral-300 font-medium">
              <input
                type="checkbox"
                checked={openInNewTab}
                onChange={e => setOpenInNewTab(e.target.checked)}
                className="rounded accent-amber-400"
              />
              <span>Abrir Hotmart en una pestaña nueva al hacer clic</span>
            </label>
          </div>

          {/* Quick Guide */}
          <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-400/20 text-amber-200 text-xs space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-amber-400">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>¿Cómo obtener tu enlace en Hotmart?</span>
            </div>
            <ol className="list-decimal list-inside space-y-1 text-[11px] text-neutral-300 font-normal">
              <li>Inicia sesión en tu cuenta de <strong className="text-white">Hotmart</strong>.</li>
              <li>Entra a <strong className="text-white">Productos &gt; Mis Productos</strong> y selecciona Radar Creativo.</li>
              <li>Ve a <strong className="text-white">Hotlinks</strong> o <strong className="text-white">Páginas de Pago (Checkouts)</strong>.</li>
              <li>Copia el link que inicia con <code className="text-amber-300 bg-black/30 px-1 py-0.5 rounded">pay.hotmart.com/...</code> y pégalo arriba.</li>
            </ol>
          </div>

          {/* Submit */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3.5 px-4 bg-amber-400 hover:bg-amber-300 text-black font-extrabold text-xs uppercase tracking-wider rounded-xl transition-all shadow-lg flex items-center justify-center gap-2"
            >
              {savedNotification ? (
                <>
                  <Check className="w-4 h-4 text-black" />
                  <span>¡Enlace de Hotmart Guardado!</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  <span>Guardar y Aplicar a Todos los Botones</span>
                </>
              )}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
